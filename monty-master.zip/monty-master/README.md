This is C programming on LIFO and FIFO Stack and Quenes.
